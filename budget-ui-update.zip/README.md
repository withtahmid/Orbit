# Budget envelope gauges

Two React + TypeScript components that show a budget envelope as a **fluid glass of money that drains as you spend**, and handles **overspending** (including going more than a whole budget over). Built for a wallet app.

- **`BudgetEnvelopeCard`** — the grid view. A full glass: icon + name + tag on top, the draining glass, then the remaining number, the state, and `spent of budget`.
- **`BudgetEnvelopeRow`** — the list view. The same liquid story in a compact row: a mini "pot" on the left, name + tag, and the remaining number on the right, with a status-colored left edge for scanning. Tapping a row is meant to open the card.

> **Implementation note for whoever wires this up (e.g. Claude Code):**
> Don't reproduce this pixel-for-pixel. Take the *mechanics* — the draining liquid, the red deficit, the >100% rescale, the three states — and **re-skin it to the app's design language** via the CSS variables and font tokens below. Match the app's surface colors, radius, spacing, and fonts; treat the bundled dark palette as a placeholder default, not a target. The behavior is the product; the chrome should look like the rest of the app.

---

## What it does (behavior spec)

The **liquid is money remaining** and falls as you spend (the empty space above is what's spent). State is derived from `spent` vs `budget`:

| State | When | Look |
|---|---|---|
| `calm` | spent < `warnAt`×budget (default 80%) | teal liquid |
| `warning` | `warnAt`×budget ≤ spent ≤ budget | amber liquid |
| `over` | spent > budget | empty of liquid; red **hatched deficit** rises from the bottom |

Overspend visualization:
- **0–100% over** — the red deficit rises against the quarter-marks (red at the halfway mark = 50% over). A full glass = one whole budget over.
- **> 100% over** — the glass **rescales**: a dashed **"1× BUDGET"** line marks where one entire budget of overspend sits, and the deficit keeps climbing **above** it. It never caps; the exact figure ("130% over budget") is always in the readout. *(In the row, the 1× line is an unlabeled tick — the labeled version lives on the card.)*

Other:
- **Currency-independent.** Numbers are plain and locale-grouped by default (no symbol). Pass `currency` only if you want one, or override formatting entirely with `formatValue`.
- **Monthly / rolling tag.** Pass `kind="monthly" | "rolling"` to show a small chip; omit for none.
- **Accessible.** Each is a `role="meter"` with `aria-valuenow/min/max` and a spoken label ("$X (Y%) over a $Z budget"); rows with `onClick` get button semantics + Enter/Space. **Reduced motion** is respected (no slosh/pulse; the deficit still renders).

---

## Requirements

- **React 18+** (uses `useId`).
- No other runtime dependencies. Pure inline SVG + a tiny `<style>` block injected once.

---

## Install

Drop the folder into your project, e.g. `src/components/budget-gauge/`:

```
budget-gauge/
  index.ts                  # public exports
  types.ts                  # public types
  internal.ts               # geometry, color tokens, hooks, styles (not part of the public API)
  BudgetEnvelopeCard.tsx     # grid view
  BudgetEnvelopeRow.tsx      # list view
  example.tsx                # reference usage — delete after wiring up
```

Then import from the barrel:

```tsx
import { BudgetEnvelopeCard, BudgetEnvelopeRow } from "@/components/budget-gauge";
import type { EnvelopeKind } from "@/components/budget-gauge";
```

---

## Props

Both components share `BudgetEnvelopeBaseProps`:

| Prop | Type | Default | Notes |
|---|---|---|---|
| `spent` | `number` | — | Amount spent this period. May exceed `budget`. |
| `budget` | `number` | — | The envelope's limit. |
| `label` | `string` | — | Display name. |
| `icon` | `ReactNode` | — | Emoji string, `<svg>`, or your own icon component. |
| `kind` | `"monthly" \| "rolling"` | — | Renders a small tag; omit for none. |
| `currency` | `string` | `""` | Optional symbol. Empty = currency-independent. |
| `currencyPosition` | `"prefix" \| "suffix"` | `"prefix"` | Where the symbol goes, if set. |
| `warnAt` | `number` | `0.8` | Fraction of budget spent where amber begins. |
| `precision` | `number` | `0` for integer budgets | Decimal places. |
| `formatValue` | `(value: number) => string` | — | Replaces built-in number formatting. |

`BudgetEnvelopeCard` adds: `height?: number` (default `240`), `className?: string`.
`BudgetEnvelopeRow` adds: `onClick?: () => void` (makes it tappable → open the card), `className?: string`.

The components **don't impose layout** — your screen owns the grid/list container.

---

## Usage

```tsx
// GRID
<div style={{ display: "grid", gap: 16, gridTemplateColumns: "repeat(auto-fill, minmax(190px, 1fr))" }}>
  {envelopes.map((e) => (
    <BudgetEnvelopeCard
      key={e.id}
      label={e.name}
      icon={e.icon}
      kind={e.kind}            // "monthly" | "rolling"
      spent={e.spent}
      budget={e.budget}
    />
  ))}
</div>

// LIST
<div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
  {envelopes.map((e) => (
    <BudgetEnvelopeRow
      key={e.id}
      label={e.name}
      icon={e.icon}
      kind={e.kind}
      spent={e.spent}
      budget={e.budget}
      onClick={() => openEnvelope(e.id)}   // opens the detail card
    />
  ))}
</div>
```

See `example.tsx` for a runnable reference (delete it once integrated).

---

## Theming (this is where you align it with the app)

Every color, the corner radius, and the fonts resolve through **CSS variables with fallbacks**. Set them once on a wrapper (or `:root`) to match the app — no need to touch the component code.

```css
.budget-gauges {
  /* surfaces & text — map these to your app's tokens */
  --env-surface-bg:     #121A22;
  --env-surface-border: #1E2A35;
  --env-surface-hover:  #16202B;
  --env-text:           #EAF1F7;
  --env-text-muted:     #7B8A99;
  --env-text-faint:     #6F7E8D;
  --env-radius:         16px;
  --env-focus:          #57C7F7;

  /* the glass vessel */
  --env-glass-housing:  #0A1015;
  --env-glass-rim:      #27343F;
  --env-glass-interior: #0C141A;
  --env-mark:           #3A4B5A;   /* quarter marks */
  --env-budget-line:    #D6E1EC;   /* the 1× budget line */

  /* small chips (icon background + tag) */
  --env-chip-bg:        #1A2530;
  --env-chip-border:    #243240;

  /* the three states — the meaningful color signal */
  --env-calm:    #2DD4BF;  --env-calm-deep:    #199C8D;  --env-calm-surface:    #88FCEE;  --env-calm-text:    #37D6C1;
  --env-warn:    #F5A623;  --env-warn-deep:    #B97912;  --env-warn-surface:    #FFD487;  --env-warn-text:    #F7B23F;
  --env-over:    #FF4D4D;  --env-over-deep:    #B92F38;  --env-over-surface:    #FF9D9D;  --env-over-text:    #FF6B6B;

  /* type — point these at the app's families */
  --env-font-sans: ui-sans-serif, system-ui, sans-serif;
  --env-font-mono: ui-monospace, SFMono-Regular, Menlo, monospace;
}
```

For a **light theme**, just remap the surface/text/glass variables (e.g. light `--env-surface-bg`, dark `--env-text`, a paler `--env-glass-interior`); the `-deep`/`-surface`/`-text` shades give you control over how the liquid reads on a light background.

> The red "alarm" glow on overspent cards/pots is defined in a keyframe with a fixed `rgba(255,80,80,…)`. If you retheme the over-color dramatically, also tweak the `beg-alarm` / `beg-glow` keyframes in `internal.ts`.

---

## Suggested adaptation checklist (for Claude Code)

1. Place the folder under your components dir; fix the import alias.
2. Wrap your envelope screen in an element with the CSS variables above, mapped to the app's existing tokens (don't invent new colors — reuse the app's).
3. Swap `--env-font-sans` / `--env-font-mono` for the app's font families.
4. Replace the emoji `icon` examples with the app's category icon component.
5. Match `--env-radius`, card padding, and gaps to the app's card style (edit the inline `padding` in the components if needed — these are intentionally minimal and safe to change).
6. Keep the **mechanics** intact: `remainingFraction`, `deficitFraction`, the state thresholds, the >100% rescale, and the reduced-motion handling. That's the part that's been designed and tested.
7. Decide what the row's `onClick` opens (typically a sheet/modal containing `BudgetEnvelopeCard` for that envelope).

## Tuning knobs (in `internal.ts`)

- `ZOOM_H` — where the "1× budget" line lands once over 100% and how the >100% range compresses (smaller = line higher, more headroom above).
- `warnAt` (per-instance prop) — when amber starts.
- The slosh durations and wave amplitude/wavelength live in each component's `Glass`/`Pot` if you want calmer or livelier motion.

## Heads-up

There's a deliberate one-frame "settle" exactly at 100% over: the glass fills to the top, then as you cross into the rescale it eases down to the 1× line and climbs again — the line appearing explains it. If you'd rather have no step, make the deficit scale continuous (the trade-off: ≤100% would fill ~78% of the glass instead of reaching the rim). Ask if you want that variant.
