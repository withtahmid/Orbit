/* Internal helpers, geometry, hooks and styles shared by both views.
 * Colors resolve through CSS variables (with sensible fallbacks) so you can
 * theme everything from your app's stylesheet — see README "Theming". */

import { useState, useEffect, useRef, useMemo, type CSSProperties } from "react";
import type { BudgetEnvelopeBaseProps, EnvelopeStatus } from "./types";

/* ---- glass geometry (SVG coordinate system: viewBox 0 0 120 220) ---------- */
export const GLASS = { IX0: 18, IX1: 102, IY0: 12, IY1: 208, IH: 196 } as const;

/* Past 100% over, the glass rescales so the deficit keeps rising without
 * capping. ZOOM_H sets where the "1× budget" line lands (= 1/(1+H) up the
 * glass) and how the >100% range compresses above it. */
export const ZOOM_H = 0.28;
export const BUDGET_LINE_FRAC = 1 / (1 + ZOOM_H); // ~0.781

export const clamp = (n: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, n));

/** Liquid level = money remaining, as a fraction of budget (0 empty, 1 full). */
export function remainingFraction(spent: number, budget: number): number {
  if (budget <= 0) return 0;
  return clamp((budget - spent) / budget, 0, 1);
}

/**
 * Deficit fill height as a fraction of the glass, from the overspend ratio
 * r = overspend / budget.
 *   r <= 1 : linear — a full glass at exactly 100% over (unchanged behavior)
 *   r >  1 : rescaled — keeps rising toward the rim but never caps
 */
export function deficitFraction(r: number): number {
  if (r <= 0) return 0;
  if (r <= 1) return clamp(r, 0, 1);
  return r / (r + ZOOM_H);
}

export function statusOf(spent: number, budget: number, warnAt: number): EnvelopeStatus {
  if (spent > budget) return "over";
  const safe = budget > 0 ? budget : 1;
  return spent / safe >= warnAt ? "warning" : "calm";
}

export interface GaugeColors { fluid: string; back: string; surface: string; text: string; }

export function colorsFor(status: EnvelopeStatus): GaugeColors {
  switch (status) {
    case "over":
      return {
        fluid: "var(--env-over, #FF4D4D)",
        back: "var(--env-over-deep, #B92F38)",
        surface: "var(--env-over-surface, #FF9D9D)",
        text: "var(--env-over-text, #FF6B6B)",
      };
    case "warning":
      return {
        fluid: "var(--env-warn, #F5A623)",
        back: "var(--env-warn-deep, #B97912)",
        surface: "var(--env-warn-surface, #FFD487)",
        text: "var(--env-warn-text, #F7B23F)",
      };
    default:
      return {
        fluid: "var(--env-calm, #2DD4BF)",
        back: "var(--env-calm-deep, #199C8D)",
        surface: "var(--env-calm-surface, #88FCEE)",
        text: "var(--env-calm-text, #37D6C1)",
      };
  }
}

export function makeFormatter(precision: number | undefined, budget: number): (v: number) => string {
  const p = precision != null ? precision : Number.isInteger(budget) ? 0 : 2;
  return (v: number) =>
    Number(Math.abs(v)).toLocaleString(undefined, {
      minimumFractionDigits: p,
      maximumFractionDigits: p,
    });
}

export function formatMoney(
  value: number,
  currency: string,
  position: "prefix" | "suffix",
  fmt: (v: number) => string,
): string {
  const num = fmt(value);
  if (!currency) return num; // currency-independent default
  return position === "suffix" ? `${num}\u00A0${currency}` : `${currency}${num}`;
}

/* ---- hooks ---------------------------------------------------------------- */

/** Eased count toward `target` (respects reduced motion via `enabled`). */
export function useTween(target: number, duration = 700, enabled = true): number {
  const [val, setVal] = useState(target);
  const cur = useRef(target);
  const raf = useRef(0);
  useEffect(() => {
    if (!enabled || duration <= 0) {
      cur.current = target;
      setVal(target);
      return;
    }
    const from = cur.current;
    const delta = target - from;
    const start = performance.now();
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      const e = 1 - Math.pow(1 - t, 3);
      cur.current = from + delta * e;
      setVal(cur.current);
      if (t < 1) raf.current = requestAnimationFrame(tick);
    };
    cancelAnimationFrame(raf.current);
    raf.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf.current);
  }, [target, duration, enabled]);
  return val;
}

export function usePrefersReducedMotion(): boolean {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;
    const m = window.matchMedia("(prefers-reduced-motion: reduce)");
    const on = () => setReduced(m.matches);
    on();
    m.addEventListener?.("change", on);
    return () => m.removeEventListener?.("change", on);
  }, []);
  return reduced;
}

/** Shared model derived from the props — used by both the card and the row. */
export function useEnvelopeModel(p: BudgetEnvelopeBaseProps) {
  const motion = !usePrefersReducedMotion();
  const safeBudget = p.budget > 0 ? p.budget : 1;
  const remaining = p.budget - p.spent;
  const overspend = Math.max(0, p.spent - p.budget);
  const over = p.spent > p.budget;
  const warnAt = p.warnAt ?? 0.8;
  const status = statusOf(p.spent, p.budget, warnAt);
  const colors = colorsFor(status);
  const overPct = Math.round((overspend / safeBudget) * 100);

  const fmt = useMemo(
    () => p.formatValue ?? makeFormatter(p.precision, p.budget),
    [p.formatValue, p.precision, p.budget],
  );
  const currency = p.currency ?? "";
  const pos = p.currencyPosition ?? "prefix";
  const money = (v: number) => formatMoney(v, currency, pos, fmt);
  const signedMoney = (v: number) => (v < 0 ? `\u2212${money(v)}` : money(v));

  const tweenedRemaining = useTween(remaining, 700, motion);
  const statusWord = over
    ? "Over budget"
    : remaining <= 0
      ? "Budget reached"
      : status === "warning"
        ? "Running low"
        : "On budget";

  return { motion, remaining, overspend, over, status, colors, overPct, money, signedMoney, tweenedRemaining, statusWord };
}

/* ---- wave geometry (built once; level via translateY, slosh via translateX) */
export function buildBody(amp: number, len: number): string {
  const x0 = -60, x1 = 180, floor = 400, step = len / 16;
  let d = `M ${x0} ${(amp * Math.sin((x0 / len) * 2 * Math.PI)).toFixed(2)}`;
  for (let x = x0 + step; x <= x1; x += step)
    d += ` L ${x.toFixed(2)} ${(amp * Math.sin((x / len) * 2 * Math.PI)).toFixed(2)}`;
  d += ` L ${x1} ${floor} L ${x0} ${floor} Z`;
  return d;
}
export function buildCrest(amp: number, len: number): string {
  const x0 = -60, x1 = 180, step = len / 16;
  let d = `M ${x0} ${(amp * Math.sin((x0 / len) * 2 * Math.PI)).toFixed(2)}`;
  for (let x = x0 + step; x <= x1; x += step)
    d += ` L ${x.toFixed(2)} ${(amp * Math.sin((x / len) * 2 * Math.PI)).toFixed(2)}`;
  return d;
}

/** A slosh animation style for a wave layer. dx must equal -wavelength for a seamless loop. */
export function sloshStyle(motion: boolean, durationSec: number, dx: number): CSSProperties {
  if (!motion) return {};
  return { animation: `beg-slosh ${durationSec}s linear infinite`, ["--beg-dx" as never]: `${dx}px` } as CSSProperties;
}

export const SANS = "var(--env-font-sans, ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, sans-serif)";
export const MONO = "var(--env-font-mono, ui-monospace, SFMono-Regular, Menlo, Consolas, monospace)";

/* ---- one-time style injection (keyframes + interaction states) ------------ */
const STYLE_ID = "budget-gauge-styles";
const CSS = `
@keyframes beg-slosh { from { transform: translateX(0); } to { transform: translateX(var(--beg-dx, 0px)); } }
@keyframes beg-alarm {
  0%,100% { box-shadow: 0 0 0 1px var(--env-surface-border, #29384a), 0 10px 26px rgba(0,0,0,.5); }
  50%     { box-shadow: 0 0 0 1px rgba(255,80,80,.55), 0 0 24px rgba(255,80,80,.3), 0 10px 26px rgba(0,0,0,.5); }
}
@keyframes beg-glow {
  0%,100% { filter: drop-shadow(0 0 1px rgba(255,80,80,.4)); }
  50%     { filter: drop-shadow(0 0 5px rgba(255,80,80,.95)); }
}
.beg-focusable:focus-visible { outline: 2px solid var(--env-focus, #57c7f7); outline-offset: 3px; border-radius: var(--env-radius, 16px); }
.beg-row { transition: background .15s, transform .08s; }
.beg-row[data-tappable="true"] { cursor: pointer; }
.beg-row[data-tappable="true"]:hover  { background: var(--env-surface-hover, #16202B); }
.beg-row[data-tappable="true"]:active { transform: scale(.997); }
`;

/** Injects the keyframes/interaction CSS once. Call from each component. */
export function useGaugeStyles(): void {
  useEffect(() => {
    if (typeof document === "undefined" || document.getElementById(STYLE_ID)) return;
    const el = document.createElement("style");
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }, []);
}
