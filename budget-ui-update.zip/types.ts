import type { ReactNode } from "react";

/** Whether the envelope resets each month or carries its balance forward. */
export type EnvelopeKind = "monthly" | "rolling";

/** Internal state derived from spent vs budget. */
export type EnvelopeStatus = "calm" | "warning" | "over";

/** Props shared by both the grid card and the list row. */
export interface BudgetEnvelopeBaseProps {
  /** Amount spent so far this period. May exceed `budget`. */
  spent: number;
  /** The envelope's limit for the period. */
  budget: number;
  /** Display name, e.g. "Groceries". */
  label: string;
  /** Optional leading icon — an emoji string, an <svg>, or your own icon node. */
  icon?: ReactNode;
  /** Tags the envelope as monthly or rolling (renders a small chip). Omit for none. */
  kind?: EnvelopeKind;
  /**
   * Optional currency/unit symbol. Empty by default — the gauge is currency-independent
   * and shows plain, locale-grouped numbers. Pass "€", "kr", etc. only if you want a symbol.
   */
  currency?: string;
  /** Where the symbol sits, if `currency` is set. Default "prefix". */
  currencyPosition?: "prefix" | "suffix";
  /** Fraction of the budget spent at which the amber "running low" state begins. Default 0.8. */
  warnAt?: number;
  /** Decimal places for the numbers. Defaults to 0 when the budget is an integer. */
  precision?: number;
  /** Replace the built-in number formatting entirely. Receives the raw number. */
  formatValue?: (value: number) => string;
}

export interface BudgetEnvelopeCardProps extends BudgetEnvelopeBaseProps {
  /** Pixel height of the glass. Default 240. */
  height?: number;
  /** Extra class on the card root, for layout/spacing from the parent grid. */
  className?: string;
}

export interface BudgetEnvelopeRowProps extends BudgetEnvelopeBaseProps {
  /** Makes the row tappable — e.g. to open the detail card. Adds button semantics. */
  onClick?: () => void;
  /** Extra class on the row root. */
  className?: string;
}
