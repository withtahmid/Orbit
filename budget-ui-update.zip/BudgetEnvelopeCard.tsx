/* Grid view — the full fluid-glass envelope.
 * Header: icon + name (+ monthly/rolling tag). Glass in the middle. Then the
 * remaining number, the state, and spent / budget. Currency-independent. */

import { useId, useMemo, type CSSProperties, type ReactNode } from "react";
import type { BudgetEnvelopeCardProps, EnvelopeKind } from "./types";
import {
  GLASS, BUDGET_LINE_FRAC, clamp, remainingFraction, deficitFraction,
  buildBody, buildCrest, sloshStyle, useEnvelopeModel, useGaugeStyles,
  SANS, MONO, type GaugeColors,
} from "./internal";
import type { EnvelopeStatus } from "./types";

function Tag({ kind }: { kind?: EnvelopeKind }) {
  if (!kind) return null;
  const text = kind === "rolling" ? "Rolling" : "Monthly";
  return (
    <span style={{
      fontFamily: SANS, fontSize: 9.5, fontWeight: 600, letterSpacing: "0.8px",
      textTransform: "uppercase", color: "var(--env-text-muted, #7B8A99)",
      padding: "3px 7px", borderRadius: 999, whiteSpace: "nowrap",
      background: "var(--env-chip-bg, #1A2530)", border: "1px solid var(--env-chip-border, #243240)",
    }}>{text}</span>
  );
}

function Glass({
  spent, budget, status, colors, motion, height, uid,
}: {
  spent: number; budget: number; status: EnvelopeStatus; colors: GaugeColors;
  motion: boolean; height: number; uid: string;
}) {
  const { IX0, IX1, IY1, IH } = GLASS;
  const w = Math.round(height * 0.55);
  const frac = remainingFraction(spent, budget);
  const fluidTopY = IY1 - frac * IH;
  const hasLiquid = frac > 0.001;
  const over = spent > budget;

  const r = over && budget > 0 ? (spent - budget) / budget : 0;
  const zoom = r > 1;
  const redFrac = deficitFraction(r);
  const deficitY = IY1 - redFrac * IH;
  const budgetLineY = IY1 - BUDGET_LINE_FRAC * IH;

  const dur = status === "warning" ? { a: 3.4, b: 5 } : { a: 5, b: 7 };
  const wave = useMemo(() => ({
    frontBody: buildBody(3.4, 40), frontCrest: buildCrest(3.4, 40), backBody: buildBody(4.6, 52),
  }), []);

  const level: CSSProperties = {
    transform: `translateY(${fluidTopY}px)`,
    transition: motion ? "transform .8s cubic-bezier(.22,1,.36,1)" : "none",
  };
  const deficit: CSSProperties = {
    transform: `translateY(${deficitY}px)`,
    transition: motion ? "transform .8s cubic-bezier(.22,1,.36,1)" : "none",
  };
  const fillT: CSSProperties = { transition: motion ? "fill .55s" : "none" };
  const strokeT: CSSProperties = { transition: motion ? "stroke .55s" : "none" };

  const clip = `${uid}-clip`, sheen = `${uid}-sheen`, hatch = `${uid}-hatch`;

  return (
    <svg viewBox="0 0 120 220" width={w} height={height} role="presentation" style={{ display: "block" }}>
      <defs>
        <clipPath id={clip}><rect x={IX0} y={GLASS.IY0} width="84" height="196" rx="12" /></clipPath>
        <linearGradient id={sheen} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#ffffff" stopOpacity="0.10" />
          <stop offset="0.22" stopColor="#ffffff" stopOpacity="0" />
        </linearGradient>
        <pattern id={hatch} width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <rect width="7" height="7" fill="var(--env-over, #FF4D4D)" fillOpacity="0.13" />
          <line x1="0" y1="0" x2="0" y2="7" stroke="var(--env-over, #FF4D4D)" strokeWidth="2.6" strokeOpacity="0.5" />
        </pattern>
      </defs>

      <rect x="13" y="7" width="94" height="206" rx="17"
            fill="var(--env-glass-housing, #0A1015)" stroke="var(--env-glass-rim, #27343F)" strokeWidth="1.5" />

      <g clipPath={`url(#${clip})`}>
        <rect x={IX0} y={GLASS.IY0} width="84" height="196" fill="var(--env-glass-interior, #0C141A)" />

        {hasLiquid && (
          <>
            <g style={level}>
              <g style={sloshStyle(motion, dur.b, -52)}>
                <path d={wave.backBody} fill={colors.back} opacity="0.55" style={fillT} />
              </g>
            </g>
            <g style={level}>
              <g style={sloshStyle(motion, dur.a, -40)}>
                <path d={wave.frontBody} fill={colors.fluid} style={fillT} />
                <path d={wave.frontCrest} fill="none" stroke={colors.surface} strokeWidth="1.6"
                      strokeLinecap="round" style={strokeT} />
              </g>
            </g>
          </>
        )}

        {over && (
          <g style={deficit}>
            <rect x={IX0} y="0" width="84" height="400" fill={`url(#${hatch})`} />
            <line x1={IX0} x2={IX1} y1="0" y2="0" stroke="var(--env-over-text, #FF6B6B)" strokeWidth="1.5"
                  strokeDasharray="5 3" strokeOpacity="0.95" />
          </g>
        )}

        {zoom && (
          <g>
            <line x1={IX0} x2={IX1} y1={budgetLineY} y2={budgetLineY}
                  stroke="var(--env-budget-line, #D6E1EC)" strokeOpacity="0.85" strokeWidth="1" strokeDasharray="2 2" />
            <text x={IX0 + 2} y={budgetLineY - 4} fontSize="7" letterSpacing="0.5"
                  fontFamily={MONO} fill="var(--env-budget-line, #C2D0DC)">1× BUDGET</text>
          </g>
        )}

        <rect x={IX0} y={GLASS.IY0} width="84" height="196" fill={`url(#${sheen})`} />

        {!zoom && [0.25, 0.5, 0.75].map((t) => (
          <line key={t} x1="95" x2="101" y1={IY1 - t * IH} y2={IY1 - t * IH}
                stroke="var(--env-mark, #3A4B5A)" strokeWidth="1" />
        ))}
      </g>
    </svg>
  );
}

export function BudgetEnvelopeCard(props: BudgetEnvelopeCardProps) {
  useGaugeStyles();
  const { spent, budget, label, icon, kind, height = 240, className } = props;
  const uid = useId().replace(/:/g, "");
  const m = useEnvelopeModel(props);

  const cardStyle: CSSProperties = {
    display: "flex", flexDirection: "column", alignItems: "center", gap: 13,
    padding: "16px 16px 18px", borderRadius: "var(--env-radius, 16px)",
    background: "var(--env-surface-bg, #121A22)", border: "1px solid var(--env-surface-border, #1E2A35)",
    ...(m.over && m.motion
      ? { animation: "beg-alarm 1.4s ease-in-out infinite" }
      : { boxShadow: "0 0 0 1px var(--env-surface-border, #29384a), 0 10px 26px rgba(0,0,0,.5)" }),
  };

  const ariaLabel = m.over
    ? `${label}: ${m.money(m.overspend)} (${m.overPct}%) over a ${m.money(budget)} budget`
    : `${label}: ${m.money(m.remaining)} left of a ${m.money(budget)} budget`;

  return (
    <div className={`beg-focusable${className ? ` ${className}` : ""}`} tabIndex={0} role="meter"
         aria-valuenow={Math.round(clamp(m.remaining, 0, budget))} aria-valuemin={0}
         aria-valuemax={Math.round(budget)} aria-label={ariaLabel} style={cardStyle}>

      {/* header: icon + name, with the monthly/rolling tag */}
      <div style={{ display: "flex", alignItems: "center", gap: 9, width: "100%" }}>
        {icon != null && (
          <span aria-hidden style={{
            flex: "0 0 auto", width: 26, height: 26, borderRadius: 8, fontSize: 15,
            display: "inline-flex", alignItems: "center", justifyContent: "center",
            background: "var(--env-chip-bg, #1A2530)", border: "1px solid var(--env-chip-border, #243240)",
          }}>{icon as ReactNode}</span>
        )}
        <span style={{
          flex: "1 1 auto", minWidth: 0, fontFamily: SANS, fontSize: 13.5, fontWeight: 600,
          color: "var(--env-text, #EAF1F7)", letterSpacing: "-0.1px",
          overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
        }}>{label}</span>
        <Tag kind={kind} />
      </div>

      <Glass spent={spent} budget={budget} status={m.status} colors={m.colors}
             motion={m.motion} height={height} uid={uid} />

      {/* bottom: remaining number, state, spent / budget */}
      <div style={{ textAlign: "center", display: "flex", flexDirection: "column", gap: 5 }}>
        <div style={{
          fontFamily: MONO, fontWeight: 600, fontSize: 30, lineHeight: 1, letterSpacing: "-0.5px",
          color: m.over ? m.colors.text : "var(--env-text, #EAF1F7)", fontVariantNumeric: "tabular-nums",
        }}>{m.signedMoney(m.tweenedRemaining)}</div>
        <div style={{
          fontFamily: SANS, fontSize: 10.5, fontWeight: 600, letterSpacing: "1px",
          textTransform: "uppercase", color: m.over ? m.colors.text : "var(--env-text-muted, #7B8A99)",
        }}>{m.over ? `${m.overPct}% over budget` : "left"}</div>
        <div style={{ fontFamily: SANS, fontSize: 12, marginTop: 2 }}>
          {!m.over && <span style={{ color: m.colors.text, fontWeight: 600 }}>{m.statusWord}</span>}
          <span style={{ color: "var(--env-text-faint, #6F7E8D)" }}>
            {!m.over ? "  ·  " : ""}{m.money(spent)} of {m.money(budget)}
          </span>
        </div>
      </div>
    </div>
  );
}

export default BudgetEnvelopeCard;
