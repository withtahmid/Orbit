/* List view — a compact row carrying the same draining "pot" of money on the
 * left, so the list tells the same liquid story as the grid. Name + tag in the
 * middle, remaining number on the right, a status-colored left edge for quick
 * scanning. Tapping a row (onClick) is meant to open the detail card.
 * Currency-independent. The pot uses the same deficit logic as the card, so an
 * overspend rises (and keeps rising past 100% over) — the precise figure lives
 * in the number; the "1× budget" label is reserved for the larger card. */

import { useId, useMemo, type CSSProperties, type ReactNode } from "react";
import type { BudgetEnvelopeRowProps, EnvelopeKind, EnvelopeStatus } from "./types";
import {
  BUDGET_LINE_FRAC, deficitFraction, remainingFraction, buildBody, buildCrest,
  sloshStyle, useEnvelopeModel, useGaugeStyles, SANS, MONO, type GaugeColors,
} from "./internal";

// mini-pot interior (viewBox 0 0 48 64)
const P = { X0: 7, X1: 41, Y0: 8, Y1: 56, H: 48 } as const;

function Tag({ kind }: { kind?: EnvelopeKind }) {
  if (!kind) return null;
  const text = kind === "rolling" ? "Rolling" : "Monthly";
  return (
    <span style={{
      fontFamily: SANS, fontSize: 9, fontWeight: 600, letterSpacing: "0.7px", textTransform: "uppercase",
      color: "var(--env-text-muted, #7B8A99)", padding: "2px 6px", borderRadius: 999, whiteSpace: "nowrap",
      background: "var(--env-chip-bg, #1A2530)", border: "1px solid var(--env-chip-border, #243240)",
    }}>{text}</span>
  );
}

function Pot({
  spent, budget, status, colors, motion, uid,
}: {
  spent: number; budget: number; status: EnvelopeStatus; colors: GaugeColors; motion: boolean; uid: string;
}) {
  const frac = remainingFraction(spent, budget);
  const fluidTopY = P.Y1 - frac * P.H;
  const hasLiquid = frac > 0.001;
  const over = spent > budget;
  const r = over && budget > 0 ? (spent - budget) / budget : 0;
  const zoom = r > 1;
  const redFrac = deficitFraction(r);
  const deficitY = P.Y1 - redFrac * P.H;
  const budgetLineY = P.Y1 - BUDGET_LINE_FRAC * P.H;

  const dur = status === "warning" ? { a: 3.4, b: 5 } : { a: 5, b: 7 };
  const wave = useMemo(() => ({
    frontBody: buildBody(1.8, 13), frontCrest: buildCrest(1.8, 13), backBody: buildBody(2.4, 17),
  }), []);

  const level: CSSProperties = {
    transform: `translateY(${fluidTopY}px)`,
    transition: motion ? "transform .7s cubic-bezier(.22,1,.36,1)" : "none",
  };
  const deficit: CSSProperties = {
    transform: `translateY(${deficitY}px)`,
    transition: motion ? "transform .7s cubic-bezier(.22,1,.36,1)" : "none",
  };
  const fillT: CSSProperties = { transition: motion ? "fill .5s" : "none" };

  const clip = `${uid}-clip`, sheen = `${uid}-sheen`, hatch = `${uid}-hatch`;

  return (
    <svg viewBox="0 0 48 64" width="40" height="54" role="presentation" style={{ display: "block" }}>
      <defs>
        <clipPath id={clip}><rect x={P.X0} y={P.Y0} width="34" height="48" rx="7" /></clipPath>
        <linearGradient id={sheen} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#ffffff" stopOpacity="0.12" />
          <stop offset="0.28" stopColor="#ffffff" stopOpacity="0" />
        </linearGradient>
        <pattern id={hatch} width="5" height="5" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <rect width="5" height="5" fill="var(--env-over, #FF4D4D)" fillOpacity="0.14" />
          <line x1="0" y1="0" x2="0" y2="5" stroke="var(--env-over, #FF4D4D)" strokeWidth="2" strokeOpacity="0.5" />
        </pattern>
      </defs>

      <rect x="3" y="4" width="42" height="56" rx="10"
            fill="var(--env-glass-housing, #0A1015)" stroke="var(--env-glass-rim, #27343F)" strokeWidth="1.4" />

      <g clipPath={`url(#${clip})`}>
        <rect x={P.X0} y={P.Y0} width="34" height="48" fill="var(--env-glass-interior, #0C141A)" />

        {hasLiquid && (
          <>
            <g style={level}>
              <g style={sloshStyle(motion, dur.b, -17)}>
                <path d={wave.backBody} fill={colors.back} opacity="0.55" style={fillT} />
              </g>
            </g>
            <g style={level}>
              <g style={sloshStyle(motion, dur.a, -13)}>
                <path d={wave.frontBody} fill={colors.fluid} style={fillT} />
                <path d={wave.frontCrest} fill="none" stroke={colors.surface} strokeWidth="1"
                      strokeLinecap="round" style={fillT} />
              </g>
            </g>
          </>
        )}

        {over && (
          <g style={deficit}>
            <rect x={P.X0} y="0" width="34" height="200" fill={`url(#${hatch})`} />
            <line x1={P.X0} x2={P.X1} y1="0" y2="0" stroke="var(--env-over-text, #FF6B6B)" strokeWidth="1"
                  strokeDasharray="3 2" strokeOpacity="0.95" />
          </g>
        )}

        {/* unlabeled 1× budget tick once past a whole budget over (label lives on the card) */}
        {zoom && (
          <line x1={P.X0} x2={P.X1} y1={budgetLineY} y2={budgetLineY}
                stroke="var(--env-budget-line, #D6E1EC)" strokeOpacity="0.8" strokeWidth="0.8" strokeDasharray="1.5 1.5" />
        )}

        <rect x={P.X0} y={P.Y0} width="34" height="48" fill={`url(#${sheen})`} />
      </g>
    </svg>
  );
}

export function BudgetEnvelopeRow(props: BudgetEnvelopeRowProps) {
  useGaugeStyles();
  const { spent, budget, label, icon, kind, onClick, className } = props;
  const uid = useId().replace(/:/g, "");
  const m = useEnvelopeModel(props);
  const tappable = typeof onClick === "function";

  const rowStyle: CSSProperties = {
    display: "flex", alignItems: "center", gap: 13,
    background: "var(--env-surface-bg, #121A22)", borderRadius: "var(--env-radius, 14px)",
    padding: "10px 14px", border: "1px solid var(--env-surface-border, #1C2731)",
    borderLeft: `3px solid ${m.colors.fluid}`,
    boxShadow: "0 6px 16px rgba(0,0,0,.35)",
  };

  const ariaLabel = m.over
    ? `${label}: ${m.money(m.overspend)} (${m.overPct}%) over a ${m.money(budget)} budget`
    : `${label}: ${m.money(m.remaining)} left of a ${m.money(budget)} budget`;

  return (
    <div className={`beg-row${className ? ` ${className}` : ""}`} data-tappable={tappable ? "true" : "false"}
         role={tappable ? "button" : "group"} aria-label={ariaLabel}
         tabIndex={tappable ? 0 : undefined} onClick={onClick}
         onKeyDown={tappable ? (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onClick?.(); } } : undefined}
         style={rowStyle}>

      <Pot spent={spent} budget={budget} status={m.status} colors={m.colors} motion={m.motion} uid={uid} />

      <div style={{ flex: "1 1 auto", minWidth: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
          {icon != null && <span aria-hidden style={{ fontSize: 14, lineHeight: 1 }}>{icon as ReactNode}</span>}
          <span style={{
            fontFamily: SANS, fontSize: 14, fontWeight: 600, color: "var(--env-text, #EAF1F7)",
            letterSpacing: "-0.1px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
          }}>{label}</span>
          <Tag kind={kind} />
        </div>
        <div style={{ fontFamily: SANS, fontSize: 11.5, marginTop: 3, whiteSpace: "nowrap",
                      overflow: "hidden", textOverflow: "ellipsis" }}>
          <span style={{ color: m.colors.text, fontWeight: 600 }}>
            {m.over ? `${m.overPct}% over` : m.statusWord}
          </span>
          <span style={{ color: "var(--env-text-faint, #6F7E8D)", fontFamily: MONO }}>
            {"  ·  "}{m.money(spent)} of {m.money(budget)}
          </span>
        </div>
      </div>

      <div style={{ flex: "0 0 auto", textAlign: "right", lineHeight: 1.2 }}>
        <div style={{ fontFamily: MONO, fontSize: 15.5, fontWeight: 600, fontVariantNumeric: "tabular-nums",
                      color: m.over ? m.colors.text : "var(--env-text, #EAF1F7)" }}>
          {m.signedMoney(m.tweenedRemaining)}
        </div>
        <div style={{ fontFamily: SANS, fontSize: 10.5, fontWeight: 600, letterSpacing: "0.4px",
                      textTransform: "uppercase", color: m.over ? m.colors.text : "var(--env-text-muted, #7B8A99)", marginTop: 1 }}>
          {m.over ? "over" : "left"}
        </div>
      </div>
    </div>
  );
}

export default BudgetEnvelopeRow;
