/* Reference usage — delete once you've wired the components into your app.
 * Lays out a grid of cards and a list of rows from the same sample data. */

import { BudgetEnvelopeCard, BudgetEnvelopeRow } from "./index";
import type { EnvelopeKind } from "./index";

interface Envelope {
  label: string;
  icon: string;
  spent: number;
  budget: number;
  kind: EnvelopeKind;
}

const ENVELOPES: Envelope[] = [
  { label: "Groceries", icon: "🛒", spent: 472, budget: 800, kind: "monthly" },
  { label: "Dining out", icon: "🍽️", spent: 540, budget: 600, kind: "monthly" },
  { label: "Rent", icon: "🏠", spent: 1500, budget: 1500, kind: "monthly" },
  { label: "Transport", icon: "🚗", spent: 118, budget: 250, kind: "rolling" },
  { label: "Entertainment", icon: "🎬", spent: 246, budget: 200, kind: "monthly" },
  { label: "Shopping", icon: "🛍️", spent: 920, budget: 400, kind: "rolling" }, // 130% over
];

export default function BudgetEnvelopesExample() {
  return (
    <div style={{ background: "#0B1014", minHeight: "100vh", padding: 24 }}>
      {/* GRID VIEW */}
      <div style={{
        display: "grid", gap: 16,
        gridTemplateColumns: "repeat(auto-fill, minmax(190px, 1fr))",
        maxWidth: 880, margin: "0 auto 28px",
      }}>
        {ENVELOPES.map((e) => (
          <BudgetEnvelopeCard key={e.label} {...e} />
        ))}
      </div>

      {/* LIST VIEW */}
      <div style={{ display: "flex", flexDirection: "column", gap: 10, maxWidth: 480, margin: "0 auto" }}>
        {ENVELOPES.map((e) => (
          <BudgetEnvelopeRow key={e.label} {...e} onClick={() => console.log("open", e.label)} />
        ))}
      </div>
    </div>
  );
}
